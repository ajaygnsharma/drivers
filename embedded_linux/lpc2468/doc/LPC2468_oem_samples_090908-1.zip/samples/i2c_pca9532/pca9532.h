#ifndef _PCA9532_H
#define _PCA9532_H

#include <general.h>

tS8 pca9532(tU8* pBuf, tU16 len, tU8* pBuf2, tU16 len2);

#endif //_PCA9532_H
