/******************************************************************************
 *
 * Copyright:
 *    (C) 2009 Embedded Artists AB
 *
 * Description:
 *    Delay functions
 *
 *****************************************************************************/
#ifndef _DELAY_H_
#define _DELAY_H_

void mdelay(tU32 ms);

#endif
